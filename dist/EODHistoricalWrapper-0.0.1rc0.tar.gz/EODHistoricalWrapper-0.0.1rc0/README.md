# EODHistoricalWrapper
Wrapper for fetching individual stock information from EODHistorical
